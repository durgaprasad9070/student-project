# Student Task Manager

A simple responsive task manager built with HTML, CSS and JavaScript.

## Features

- Add tasks
- Complete tasks
- Delete tasks
- Search tasks
- LocalStorage data saving
- Responsive design
- CSS animations

## Run

Open `index.html` in a browser.

## Technologies

HTML5  
CSS3  
JavaScript  
LocalStorage
